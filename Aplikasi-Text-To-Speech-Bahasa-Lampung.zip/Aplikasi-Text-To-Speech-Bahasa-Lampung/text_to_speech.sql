-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2019 at 05:03 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `text_to_speech`
--

-- --------------------------------------------------------

--
-- Table structure for table `text`
--

CREATE TABLE `text` (
  `id_kata` int(100) NOT NULL,
  `kata` varchar(100) NOT NULL,
  `diphone` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `text`
--

INSERT INTO `text` (`id_kata`, `kata`, `diphone`) VALUES
(1, 'haga', '_/h//h/a//a/g//g/a//a/_'),
(2, 'abang', '_/a//a/b//b/a//a/ng//ng/_'),
(3, 'acagha', '_/a//a/c//c/a//a/gh//gh/a//a/_'),
(7, 'mengan', 'java.io.BufferedReader@69ea3742'),
(8, 'mengan', 'java.util.stream.IntPipeline$Head@3cef309d'),
(9, 'cawa', 'java.util.stream.IntPipeline$Head@3cef309d'),
(10, 'cawa', 'java.util.stream.IntPipeline$Head@3cef309d'),
(11, 'cutik', 'java.util.stream.IntPipeline$Head@30b8a058'),
(12, 'balak', 'java.util.stream.IntPipeline$Head@30b8a058'),
(13, 'ceghdas', 'java.util.stream.IntPipeline$Head@3cef309d'),
(14, 'cutik', 'java.util.stream.IntPipeline$Head@49fc609f'),
(15, 'catugh', 'java.util.stream.IntPipeline$Head@cd2dae5'),
(16, '', 'java.util.stream.IntPipeline$Head@3a883ce7'),
(17, '', 'java.util.stream.IntPipeline$Head@4973813a'),
(18, 'cattik', 'java.util.stream.IntPipeline$Head@3cef309d'),
(19, 'baik', 'java.util.stream.IntPipeline$Head@49fc609f'),
(20, 'guwai', 'java.util.stream.IntPipeline$Head@3cef309d'),
(21, 'ujo', 'java.util.stream.IntPipeline$Head@49fc609f'),
(22, 'adji', 'java.util.stream.IntPipeline$Head@cd2dae5'),
(23, 'saya', 'java.util.stream.IntPipeline$Head@3cef309d'),
(24, 'saya', 'java.util.stream.IntPipeline$Head@3cef309d'),
(25, 'misal', 'java.util.stream.IntPipeline$Head@3cef309d');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `text`
--
ALTER TABLE `text`
  ADD PRIMARY KEY (`id_kata`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `text`
--
ALTER TABLE `text`
  MODIFY `id_kata` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
